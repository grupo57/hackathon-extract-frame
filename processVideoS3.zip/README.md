# hackathon-extract-frame
Microserviço responsável por realizar a extração de frames de videos enviados ao S3
